﻿namespace Bo_Ok
{
    partial class Main
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.contentPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.PlaylistyHover = new System.Windows.Forms.Panel();
            this.UlubioneHover = new System.Windows.Forms.Panel();
            this.BtnPlaylisty = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUlubione = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UstawieniaHover = new System.Windows.Forms.Panel();
            this.HomeHover = new System.Windows.Forms.Panel();
            this.btnUstawienia = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.NazwaUzytkownika = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSzukaj = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.contentPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // contentPanel
            // 
            this.contentPanel.Controls.Add(this.panel1);
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.contentPanel.Location = new System.Drawing.Point(0, 0);
            this.contentPanel.Margin = new System.Windows.Forms.Padding(0);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(198, 600);
            this.contentPanel.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(51)))), ((int)(((byte)(59)))));
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.PlaylistyHover);
            this.panel1.Controls.Add(this.UlubioneHover);
            this.panel1.Controls.Add(this.BtnPlaylisty);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnUlubione);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.UstawieniaHover);
            this.panel1.Controls.Add(this.HomeHover);
            this.panel1.Controls.Add(this.btnUstawienia);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(198, 600);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.button1.Location = new System.Drawing.Point(0, 502);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 49);
            this.button1.TabIndex = 13;
            this.button1.Text = "Ustawienia";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // PlaylistyHover
            // 
            this.PlaylistyHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.PlaylistyHover.Location = new System.Drawing.Point(-2, 355);
            this.PlaylistyHover.Name = "PlaylistyHover";
            this.PlaylistyHover.Size = new System.Drawing.Size(6, 40);
            this.PlaylistyHover.TabIndex = 0;
            this.PlaylistyHover.Visible = false;
            // 
            // UlubioneHover
            // 
            this.UlubioneHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.UlubioneHover.Location = new System.Drawing.Point(-2, 310);
            this.UlubioneHover.Name = "UlubioneHover";
            this.UlubioneHover.Size = new System.Drawing.Size(6, 40);
            this.UlubioneHover.TabIndex = 0;
            this.UlubioneHover.Visible = false;
            // 
            // BtnPlaylisty
            // 
            this.BtnPlaylisty.FlatAppearance.BorderSize = 0;
            this.BtnPlaylisty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPlaylisty.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPlaylisty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.BtnPlaylisty.Location = new System.Drawing.Point(-2, 355);
            this.BtnPlaylisty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnPlaylisty.Name = "BtnPlaylisty";
            this.BtnPlaylisty.Size = new System.Drawing.Size(200, 40);
            this.BtnPlaylisty.TabIndex = 12;
            this.BtnPlaylisty.Text = "Czytane";
            this.BtnPlaylisty.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label3.Location = new System.Drawing.Point(-5, 282);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.label3.Size = new System.Drawing.Size(200, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "BIBLIOTEKA";
            // 
            // btnUlubione
            // 
            this.btnUlubione.FlatAppearance.BorderSize = 0;
            this.btnUlubione.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUlubione.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUlubione.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.btnUlubione.Location = new System.Drawing.Point(-2, 310);
            this.btnUlubione.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUlubione.Name = "btnUlubione";
            this.btnUlubione.Size = new System.Drawing.Size(200, 40);
            this.btnUlubione.TabIndex = 8;
            this.btnUlubione.Text = "Ulubione";
            this.btnUlubione.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(0, 154);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.label1.Size = new System.Drawing.Size(198, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "MENU";
            // 
            // UstawieniaHover
            // 
            this.UstawieniaHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.UstawieniaHover.Location = new System.Drawing.Point(0, 502);
            this.UstawieniaHover.Name = "UstawieniaHover";
            this.UstawieniaHover.Size = new System.Drawing.Size(6, 49);
            this.UstawieniaHover.TabIndex = 2;
            this.UstawieniaHover.Visible = false;
            // 
            // HomeHover
            // 
            this.HomeHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.HomeHover.Location = new System.Drawing.Point(0, 177);
            this.HomeHover.Name = "HomeHover";
            this.HomeHover.Size = new System.Drawing.Size(6, 40);
            this.HomeHover.TabIndex = 0;
            // 
            // btnUstawienia
            // 
            this.btnUstawienia.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnUstawienia.FlatAppearance.BorderSize = 0;
            this.btnUstawienia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUstawienia.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUstawienia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.btnUstawienia.Location = new System.Drawing.Point(0, 551);
            this.btnUstawienia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUstawienia.Name = "btnUstawienia";
            this.btnUstawienia.Size = new System.Drawing.Size(198, 49);
            this.btnUstawienia.TabIndex = 4;
            this.btnUstawienia.Text = "Schowaj";
            this.btnUstawienia.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.NazwaUzytkownika);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(20);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.panel2.Size = new System.Drawing.Size(198, 154);
            this.panel2.TabIndex = 1;
            // 
            // NazwaUzytkownika
            // 
            this.NazwaUzytkownika.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NazwaUzytkownika.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.NazwaUzytkownika.Location = new System.Drawing.Point(0, 104);
            this.NazwaUzytkownika.Name = "NazwaUzytkownika";
            this.NazwaUzytkownika.Size = new System.Drawing.Size(198, 50);
            this.NazwaUzytkownika.TabIndex = 1;
            this.NazwaUzytkownika.Text = "Nazwa Użytkownika";
            this.NazwaUzytkownika.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel3.Controls.Add(this.MainPanel);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 20);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(198, 84);
            this.panel3.TabIndex = 0;
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHome.Location = new System.Drawing.Point(0, 176);
            this.btnHome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(200, 40);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            // 
            // MainPanel
            // 
            this.MainPanel.Location = new System.Drawing.Point(198, 12);
            this.MainPanel.Margin = new System.Windows.Forms.Padding(0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(685, 568);
            this.MainPanel.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(779, 0);
            this.button2.Margin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(49, 32);
            this.button2.TabIndex = 7;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // CloseButton
            // 
            this.CloseButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CloseButton.BackgroundImage")));
            this.CloseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CloseButton.FlatAppearance.BorderSize = 0;
            this.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButton.Location = new System.Drawing.Point(834, 0);
            this.CloseButton.Margin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(49, 32);
            this.CloseButton.TabIndex = 6;
            this.CloseButton.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(243, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(371, 22);
            this.textBox1.TabIndex = 8;
            // 
            // btnSzukaj
            // 
            this.btnSzukaj.FlatAppearance.BorderSize = 0;
            this.btnSzukaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSzukaj.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSzukaj.ForeColor = System.Drawing.Color.Black;
            this.btnSzukaj.Location = new System.Drawing.Point(620, 1);
            this.btnSzukaj.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSzukaj.Name = "btnSzukaj";
            this.btnSzukaj.Size = new System.Drawing.Size(110, 29);
            this.btnSzukaj.TabIndex = 14;
            this.btnSzukaj.Text = "Szukaj";
            this.btnSzukaj.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.panel4.Location = new System.Drawing.Point(0, 223);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(6, 40);
            this.panel4.TabIndex = 15;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("PMingLiU-ExtB", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.Location = new System.Drawing.Point(0, 222);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(200, 40);
            this.btnSearch.TabIndex = 16;
            this.btnSearch.Text = "Szukaj";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 600);
            this.ControlBox = false;
            this.Controls.Add(this.btnSzukaj);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.contentPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.Text = "Form1";
            this.contentPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel PlaylistyHover;
        private System.Windows.Forms.Panel UlubioneHover;
        private System.Windows.Forms.Button BtnPlaylisty;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnUlubione;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel UstawieniaHover;
        private System.Windows.Forms.Panel HomeHover;
        private System.Windows.Forms.Button btnUstawienia;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label NazwaUzytkownika;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnSzukaj;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSearch;
    }
}

