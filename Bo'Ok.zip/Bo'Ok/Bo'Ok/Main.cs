﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bo_Ok
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            MainPanel.Controls.Add(home);
            home.BringToFront();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnUlubione_Click(object sender, EventArgs e)
        {
            Ulubione ulubione = new Ulubione();
            MainPanel.Controls.Add(ulubione);
            ulubione.BringToFront();

        }

        private void BtnCzytane_Click(object sender, EventArgs e)
        {
            Czytane czytane = new Czytane();
            MainPanel.Controls.Add(czytane);
            czytane.BringToFront();
        }

        private void btnUstawienia_Click(object sender, EventArgs e)
        {
            Ustawienia ustawienia = new Ustawienia();
            MainPanel.Controls.Add(ustawienia);
            ustawienia.BringToFront();
        }
    }
}
