﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bo_Ok
{
    public partial class Rejestracja : UserControl
    {
        public Rejestracja()
        {
            InitializeComponent();
        }

        private void Rpokazhaslo_CheckedChanged(object sender, EventArgs e)
        {
            if (Rpokazhaslo.Checked == true)
            {
                Rhaslo.UseSystemPasswordChar = true;
                Rpowhaslo.UseSystemPasswordChar = true;
            }
            else if (Rpokazhaslo.Checked == false)
            {
                Rhaslo.UseSystemPasswordChar = false;
                Rpowhaslo.UseSystemPasswordChar = false;
            }
        }
    }
}
