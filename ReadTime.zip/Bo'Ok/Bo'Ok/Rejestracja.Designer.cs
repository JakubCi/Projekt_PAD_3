﻿namespace Bo_Ok
{
    partial class Rejestracja
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rejestracja));
            this.Rpokazhaslo = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Rnazwisko = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Rimie = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Remail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Rpowhaslo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Rhaslo = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Rlogin = new System.Windows.Forms.TextBox();
            this.btnZarejestruj = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Rpokazhaslo
            // 
            this.Rpokazhaslo.AutoSize = true;
            this.Rpokazhaslo.Checked = true;
            this.Rpokazhaslo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Rpokazhaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rpokazhaslo.ForeColor = System.Drawing.Color.Gray;
            this.Rpokazhaslo.Location = new System.Drawing.Point(19, 393);
            this.Rpokazhaslo.Margin = new System.Windows.Forms.Padding(4);
            this.Rpokazhaslo.Name = "Rpokazhaslo";
            this.Rpokazhaslo.Size = new System.Drawing.Size(141, 29);
            this.Rpokazhaslo.TabIndex = 60;
            this.Rpokazhaslo.Text = "Pokaż hasło";
            this.Rpokazhaslo.UseVisualStyleBackColor = true;
            this.Rpokazhaslo.CheckedChanged += new System.EventHandler(this.Rpokazhaslo_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(223, 14);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 18);
            this.label6.TabIndex = 59;
            this.label6.Text = "Nazwisko:";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.ForeColor = System.Drawing.Color.Gray;
            this.panel6.Location = new System.Drawing.Point(227, 36);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(39, 36);
            this.panel6.TabIndex = 58;
            // 
            // Rnazwisko
            // 
            this.Rnazwisko.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Rnazwisko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Rnazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Rnazwisko.ForeColor = System.Drawing.Color.Gray;
            this.Rnazwisko.Location = new System.Drawing.Point(266, 36);
            this.Rnazwisko.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Rnazwisko.Multiline = true;
            this.Rnazwisko.Name = "Rnazwisko";
            this.Rnazwisko.Size = new System.Drawing.Size(169, 37);
            this.Rnazwisko.TabIndex = 57;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(15, 15);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 18);
            this.label5.TabIndex = 56;
            this.label5.Text = "Imię:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.ForeColor = System.Drawing.Color.Gray;
            this.panel5.Location = new System.Drawing.Point(19, 37);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(39, 36);
            this.panel5.TabIndex = 55;
            // 
            // Rimie
            // 
            this.Rimie.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Rimie.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Rimie.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Rimie.ForeColor = System.Drawing.Color.Gray;
            this.Rimie.Location = new System.Drawing.Point(59, 37);
            this.Rimie.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Rimie.Multiline = true;
            this.Rimie.Name = "Rimie";
            this.Rimie.Size = new System.Drawing.Size(167, 37);
            this.Rimie.TabIndex = 54;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(15, 160);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 18);
            this.label4.TabIndex = 53;
            this.label4.Text = "Email:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ForeColor = System.Drawing.Color.Gray;
            this.panel4.Location = new System.Drawing.Point(19, 182);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(39, 36);
            this.panel4.TabIndex = 52;
            // 
            // Remail
            // 
            this.Remail.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Remail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Remail.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Remail.ForeColor = System.Drawing.Color.Gray;
            this.Remail.Location = new System.Drawing.Point(59, 182);
            this.Remail.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Remail.Multiline = true;
            this.Remail.Name = "Remail";
            this.Remail.Size = new System.Drawing.Size(376, 37);
            this.Remail.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(15, 312);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 18);
            this.label1.TabIndex = 50;
            this.label1.Text = "Powtórz hasło:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ForeColor = System.Drawing.Color.Gray;
            this.panel1.Location = new System.Drawing.Point(19, 335);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(39, 36);
            this.panel1.TabIndex = 49;
            // 
            // Rpowhaslo
            // 
            this.Rpowhaslo.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Rpowhaslo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Rpowhaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Rpowhaslo.ForeColor = System.Drawing.Color.Gray;
            this.Rpowhaslo.Location = new System.Drawing.Point(59, 335);
            this.Rpowhaslo.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Rpowhaslo.Multiline = true;
            this.Rpowhaslo.Name = "Rpowhaslo";
            this.Rpowhaslo.PasswordChar = '*';
            this.Rpowhaslo.Size = new System.Drawing.Size(376, 37);
            this.Rpowhaslo.TabIndex = 48;
            this.Rpowhaslo.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(15, 236);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 18);
            this.label3.TabIndex = 47;
            this.label3.Text = "Hasło:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(15, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 46;
            this.label2.Text = "Login:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.ForeColor = System.Drawing.Color.Gray;
            this.panel3.Location = new System.Drawing.Point(19, 259);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(39, 36);
            this.panel3.TabIndex = 45;
            // 
            // Rhaslo
            // 
            this.Rhaslo.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Rhaslo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Rhaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Rhaslo.ForeColor = System.Drawing.Color.Gray;
            this.Rhaslo.Location = new System.Drawing.Point(58, 259);
            this.Rhaslo.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Rhaslo.Multiline = true;
            this.Rhaslo.Name = "Rhaslo";
            this.Rhaslo.PasswordChar = '*';
            this.Rhaslo.Size = new System.Drawing.Size(377, 37);
            this.Rhaslo.TabIndex = 43;
            this.Rhaslo.UseSystemPasswordChar = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.ForeColor = System.Drawing.Color.Gray;
            this.panel2.Location = new System.Drawing.Point(19, 109);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(39, 36);
            this.panel2.TabIndex = 44;
            // 
            // Rlogin
            // 
            this.Rlogin.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Rlogin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Rlogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Rlogin.ForeColor = System.Drawing.Color.Gray;
            this.Rlogin.Location = new System.Drawing.Point(59, 109);
            this.Rlogin.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.Rlogin.Multiline = true;
            this.Rlogin.Name = "Rlogin";
            this.Rlogin.Size = new System.Drawing.Size(376, 37);
            this.Rlogin.TabIndex = 42;
            // 
            // btnZarejestruj
            // 
            this.btnZarejestruj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.btnZarejestruj.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnZarejestruj.FlatAppearance.BorderSize = 0;
            this.btnZarejestruj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnZarejestruj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnZarejestruj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZarejestruj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZarejestruj.Location = new System.Drawing.Point(59, 453);
            this.btnZarejestruj.Margin = new System.Windows.Forms.Padding(4);
            this.btnZarejestruj.Name = "btnZarejestruj";
            this.btnZarejestruj.Size = new System.Drawing.Size(325, 47);
            this.btnZarejestruj.TabIndex = 41;
            this.btnZarejestruj.Text = "Zarejestruj się";
            this.btnZarejestruj.UseVisualStyleBackColor = false;
            // 
            // Rejestracja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(51)))), ((int)(((byte)(59)))));
            this.Controls.Add(this.Rpokazhaslo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.Rnazwisko);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.Rimie);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.Remail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Rpowhaslo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Rhaslo);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Rlogin);
            this.Controls.Add(this.btnZarejestruj);
            this.Name = "Rejestracja";
            this.Size = new System.Drawing.Size(450, 515);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Rpokazhaslo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.TextBox Rnazwisko;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.TextBox Rimie;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.TextBox Remail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TextBox Rpowhaslo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox Rhaslo;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.TextBox Rlogin;
        private System.Windows.Forms.Button btnZarejestruj;
    }
}
